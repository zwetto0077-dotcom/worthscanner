package de.worthscanner;

import net.fabricmc.api.ClientModInitializer;

public class WorthScannerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        WorthScanner.init();
    }
}
