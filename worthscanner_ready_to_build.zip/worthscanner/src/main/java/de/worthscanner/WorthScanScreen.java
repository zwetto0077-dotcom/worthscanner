package de.worthscanner;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;

public class WorthScanScreen extends Screen {

    private final Screen parent;
    private ButtonWidget scanButton;
    private ButtonWidget backButton;

    public WorthScanScreen(Screen parent) {
        super(Text.literal("Worth Scanner"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int base = height / 2;

        scanButton = addDrawableChild(ButtonWidget.builder(Text.literal("Scan all worthes"), b -> {
            if (WorthScanner.isRunning()) {
                WorthScanner.cancel();
            } else {
                WorthScanner.start(client);
            }
        }).dimensions(cx - 100, base + 12, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Open file"), b -> openFolder())
                .dimensions(cx - 100, base + 36, 200, 20).build());

        backButton = addDrawableChild(ButtonWidget.builder(Text.literal("Zurück"), b -> close())
                .dimensions(cx - 100, base + 66, 200, 20).build());
    }

    private void openFolder() {
        try {
            Files.createDirectories(WorthScanner.DIR);
            Util.getOperatingSystem().open(WorthScanner.DIR.toUri());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateButtons() {
        boolean running = WorthScanner.isRunning();
        scanButton.setMessage(Text.literal(running ? "Abbrechen" : "Scan all worthes"));
        scanButton.active = running || client.player != null;
        backButton.active = !running;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateButtons();
        super.render(ctx, mouseX, mouseY, delta);

        int cx = width / 2;
        int base = height / 2;

        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Worth Scanner").formatted(Formatting.BOLD), cx, base - 90, 0xFFFFFFFF);

        if (WorthScanner.isRunning()) {
            int done = WorthScanner.getProcessed();
            int total = Math.max(1, WorthScanner.getTotal());
            double frac = Math.min(1.0, done / (double) total);
            int secs = WorthScanner.getRemainingSeconds();

            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("! NICHTS MACHEN !").formatted(Formatting.RED, Formatting.BOLD),
                    cx, base - 70, 0xFFFF5555);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Der Scan läuft, bitte warten..."), cx, base - 52, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(done + " / " + total + " Items (" + (int) (frac * 100) + "%)"),
                    cx, base - 40, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Aktuell: " + WorthScanner.getCurrentCommand()), cx, base - 28, 0xFFAAAAAA);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(String.format("Verbleibend: ca. %d:%02d Min", secs / 60, secs % 60)),
                    cx, base - 16, 0xFFAAAAAA);

            ctx.fill(cx - 100, base - 2, cx + 100, base + 4, 0xFF333333);
            ctx.fill(cx - 100, base - 2, cx - 100 + (int) (200 * frac), base + 4, 0xFF55FF55);
        } else if (WorthScanner.isFinished()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(WorthScanner.getResult()), cx, base - 40, 0xFF55FF55);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Datei: config/worthscanner/prices.yml"), cx, base - 26, 0xFFAAAAAA);
        } else if (client.player == null) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Du musst auf dem Server sein, um zu scannen."), cx, base - 40, 0xFFFF5555);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Scannt alle Items per /worth <item>."), cx, base - 40, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return !WorthScanner.isRunning();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (WorthScanner.isRunning()) return;
        client.setScreen(parent);
    }
}
