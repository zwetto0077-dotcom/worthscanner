package de.worthscanner;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WorthScanner {

    private WorthScanner() {}

    public static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("worthscanner");
    public static final Path FILE = DIR.resolve("prices.yml");

    // Ticks zwischen zwei Befehlen (20 = 1 Sekunde). Bei Spam-Kick erhöhen.
    private static final int DELAY_TICKS = 20;
    // Wartezeit auf die Serverantwort.
    private static final int TIMEOUT_TICKS = 50;
    // Wie oft ein Item bei völliger Stille des Servers erneut versucht wird.
    private static final int MAX_RETRIES = 2;

    private static final Pattern PRICE = Pattern.compile(
            "(\\d[\\d.,]*)\\s*(?:(Mrd|Mio|[kKmMbB])(?![\\p{L}]))?");

    private static final Deque<Identifier> queue = new ArrayDeque<>();
    private static final Map<Identifier, Integer> retries = new HashMap<>();
    private static final Map<String, Double> prices = new TreeMap<>();
    private static final Set<String> unsellable = new TreeSet<>();

    private static boolean running = false;
    private static boolean finished = false;
    private static boolean sawMessage = false;
    private static Identifier current = null;
    private static int waitTicks = 0, cooldown = 0;
    private static int total = 0, processed = 0, found = 0, lastSaved = 0;
    private static String result = "";

    public static void init() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> onMessage(message.getString()));
        ClientTickEvents.END_CLIENT_TICK.register(WorthScanner::tick);
    }

    // ---------- Steuerung ----------

    public static boolean start(MinecraftClient client) {
        if (running || client.player == null) return false;

        prices.clear();
        unsellable.clear();
        retries.clear();
        queue.clear();

        List<Identifier> ids = new ArrayList<>(Registries.ITEM.getIds());
        ids.sort(Comparator.comparing(Identifier::getPath));
        for (Identifier id : ids) {
            if (!id.getNamespace().equals("minecraft")) continue;
            if (Registries.ITEM.get(id) == Items.AIR) continue;
            queue.add(id);
        }

        total = queue.size();
        processed = 0;
        found = 0;
        lastSaved = 0;
        current = null;
        cooldown = 0;
        result = "";
        finished = false;
        running = true;
        return true;
    }

    public static void cancel() {
        if (!running) return;
        running = false;
        finished = true;
        current = null;
        queue.clear();
        save();
        result = "Abgebrochen. " + prices.size() + " Preise gespeichert.";
    }

    // ---------- Status für den Screen ----------

    public static boolean isRunning() { return running; }
    public static boolean isFinished() { return finished; }
    public static int getTotal() { return total; }
    public static int getProcessed() { return processed; }
    public static String getResult() { return result; }
    public static String getCurrentCommand() {
        return current == null ? "" : "/worth " + current.getPath();
    }
    public static int getRemainingSeconds() {
        int left = queue.size() + (current != null ? 1 : 0);
        return left * (DELAY_TICKS + 5) / 20;
    }

    // ---------- Ablauf ----------

    private static void tick(MinecraftClient client) {
        if (!running) return;

        if (client.player == null || client.getNetworkHandler() == null) {
            running = false;
            finished = true;
            current = null;
            queue.clear();
            save();
            result = "Verbindung getrennt. " + prices.size() + " Preise gespeichert.";
            return;
        }

        if (current != null) {
            if (++waitTicks > TIMEOUT_TICKS) {
                if (!sawMessage && retries.merge(current, 1, Integer::sum) <= MAX_RETRIES) {
                    queue.add(current); // am Ende nochmal versuchen
                } else {
                    unsellable.add(key(current));
                    processed++;
                }
                current = null;
                cooldown = DELAY_TICKS;
            }
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (queue.isEmpty()) {
            running = false;
            finished = true;
            save();
            result = "Fertig! " + found + " Preise gefunden, " + unsellable.size()
                    + " Items ohne Preis (0.0).";
            return;
        }

        if (processed - lastSaved >= 100) {
            lastSaved = processed;
            save();
        }

        current = queue.poll();
        waitTicks = 0;
        sawMessage = false;
        client.getNetworkHandler().sendChatCommand("worth " + current.getPath());
    }

    private static void onMessage(String text) {
        if (!running || current == null) return;
        sawMessage = true;

        Double price = parsePrice(text);
        if (price == null) return;

        prices.put(key(current), price);
        found++;
        processed++;
        current = null;
        cooldown = DELAY_TICKS;
    }

    // ---------- Hilfsmethoden ----------

    private static String key(Identifier id) {
        return id.getPath().toUpperCase(Locale.ROOT);
    }

    /** Erste Zahl der Nachricht (unterstützt 1.500,50 / 1,500.50 / 5k / 2 Mio / 1 Mrd). */
    static Double parsePrice(String text) {
        Matcher m = PRICE.matcher(text);
        if (!m.find()) return null;
        try {
            double value = parseNumber(m.group(1));
            String suffix = m.group(2);
            if (suffix != null) {
                switch (suffix) {
                    case "k", "K" -> value *= 1_000;
                    case "m", "M", "Mio" -> value *= 1_000_000;
                    case "b", "B", "Mrd" -> value *= 1_000_000_000;
                    default -> {}
                }
            }
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static double parseNumber(String s) {
        s = s.replaceAll("[.,]+$", "");
        int lastDot = s.lastIndexOf('.');
        int lastComma = s.lastIndexOf(',');
        int sep = Math.max(lastDot, lastComma);
        if (sep < 0) return Double.parseDouble(s);

        char sepChar = s.charAt(sep);
        boolean both = lastDot >= 0 && lastComma >= 0;
        long sameCount = s.chars().filter(c -> c == sepChar).count();
        int digitsAfter = s.length() - sep - 1;
        String intPart = s.substring(0, sep).replaceAll("[.,]", "");

        boolean decimal = both || (sameCount == 1 && (digitsAfter != 3 || intPart.equals("0")));
        if (decimal) {
            return Double.parseDouble(intPart + "." + s.substring(sep + 1));
        }
        return Double.parseDouble(s.replaceAll("[.,]", ""));
    }

    private static String fmt(double v) {
        String s = BigDecimal.valueOf(v).stripTrailingZeros().toPlainString();
        return s.contains(".") ? s : s + ".0";
    }

    private static void save() {
        try {
            Files.createDirectories(DIR);
            Map<String, Double> all = new TreeMap<>();
            for (String k : unsellable) all.put(k, 0.0);
            all.putAll(prices);

            StringBuilder sb = new StringBuilder();
            sb.append("# Verkaufspreise pro Item (pro Stück). 0.0 = nicht verkaufbar.\n");
            sb.append("# Fehlende Items werden beim Start automatisch mit 0.0 ergänzt.\n");
            sb.append("prices:\n");
            for (Map.Entry<String, Double> e : all.entrySet()) {
                sb.append("  ").append(e.getKey()).append(": ").append(fmt(e.getValue())).append('\n');
            }
            Files.writeString(FILE, sb.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
