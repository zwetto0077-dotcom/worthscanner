Worth Scanner (Fabric 1.21.11) - Gradle 9.2+

Bauen:
1. Java 21 (oder neuer) installieren.
2. Projekt in IntelliJ als Gradle-Projekt oeffnen. Die Datei
   gradle/wrapper/gradle-wrapper.properties ist auf Gradle 9.2.0 eingestellt
   (IntelliJ: Settings > Build Tools > Gradle > "Use Gradle from: wrapper").
   Alternativ im Ordner mit installiertem Gradle 9.2+ ausfuehren:
       gradle wrapper --gradle-version 9.2.0
       ./gradlew build        (Windows: gradlew.bat build)
3. Die JAR aus build/libs/ (ohne -sources) in den mods-Ordner legen, zusammen mit Fabric API und Mod Menu.
4. Auf dem Server: Mod Menu -> Worth Scanner -> Einstellungen -> "Scan all worthes".
5. "Open file" oeffnet den Ordner config/worthscanner/ mit der prices.yml.

Versionen in gradle.properties ggf. auf https://fabricmc.net/develop anpassen.
